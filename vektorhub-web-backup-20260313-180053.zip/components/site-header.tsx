"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Menu, UserCircle2, X, ChevronDown, ChevronRight } from "lucide-react";

const navItems = [
  { href: "/", label: "Ana Sayfa" },
  { href: "/about", label: "Hakkımızda" },
  { href: "/misyon", label: "Misyon" },
  { href: "/vizyon", label: "Vizyon" },
  {
    href: "/faaliyetler",
    label: "Faaliyetler",
    children: [
      { href: "/faaliyetler/uretim", label: "Üretim" },
      { href: "/faaliyetler/planlama", label: "Planlama" },
    ],
  },
  {
    href: "/hizmetler",
    label: "Hizmetler",
    children: [
      { href: "/hizmetler/danismanlik", label: "Danışmanlık" },
      { href: "/hizmetler/eglence", label: "Proje Yönetimi" },
    ],
  },
  { href: "/referanslar", label: "Referanslar" },
  { href: "/iletisim", label: "İletişim" },
];

const weekDays = ["Pt", "Sa", "Ça", "Pe", "Cu", "Ct", "Pa"];

export function SiteHeader() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [openSubmenu, setOpenSubmenu] = useState<string | null>(null);
  const today = new Date();
  const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
  const monthLabel = new Intl.DateTimeFormat("tr-TR", {
    month: "long",
    year: "numeric",
  }).format(today);
  const startOffset = (firstDayOfMonth.getDay() + 6) % 7;
  const daysInMonth = lastDayOfMonth.getDate();
  const calendarDays = [
    ...Array.from({ length: startOffset }, () => null),
    ...Array.from({ length: daysInMonth }, (_, index) => index + 1),
  ];

  while (calendarDays.length % 7 !== 0) {
    calendarDays.push(null);
  }

  useEffect(() => {
    document.body.dataset.leftSidebar = sidebarOpen ? "open" : "collapsed";
    window.dispatchEvent(
      new CustomEvent("left-sidebar-change", {
        detail: { open: sidebarOpen },
      })
    );

    return () => {
      delete document.body.dataset.leftSidebar;
    };
  }, [sidebarOpen]);

  return (
    <header className="sticky top-0 z-50">

      {/* İNCE ENERJİ ŞERİDİ - Kaldırıldı (talep üzerine) */}

      {/* NAVBAR */}
      <div
        className="relative border-b border-white/10 backdrop-blur-md"
        style={{
          backgroundImage:
            "linear-gradient(rgba(7,16,29,0.55), rgba(7,16,29,0.55)), url('/header-flow.png')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          backgroundBlendMode: "overlay",
        }}
      >

        <div className="container-main flex min-h-[120px] items-end justify-end gap-4 py-4">

          {/* LOGO */}
          <Link href="/" className="flex items-center gap-3 lg:absolute lg:left-2 lg:top-3">
            <div className="h-14 w-14 md:h-14 md:w-14 lg:h-16 lg:w-16 rounded-xl overflow-hidden flex items-center justify-center bg-[#07101d] p-1">
              <img src="/logo.png" alt="VektörHUB" className="h-full w-full object-contain bg-transparent" />
            </div>

            <div>
              <div className="text-base font-extrabold text-white">
                Vektör<span className="text-[#ff6a00]">HUB</span>
              </div>
              <div className="text-xs text-white/70">
                İş Geliştirme • Dijital Çözümler
              </div>
            </div>
          </Link>

          {/* TOP MENU removed — moved to left sidebar */}

          {/* BUTTON */}
          <div className="flex items-end gap-3 self-end">

            <Link
              href="/musteri-girisi"
              className="hidden md:flex items-center gap-1 self-end rounded-lg bg-orange-500 px-2.5 py-1.5 text-[11px] font-semibold text-white shadow-lg shadow-orange-500/20 hover:scale-[1.02]"
            >
              <UserCircle2 className="h-3 w-3" />
              Müşteri Girişi
            </Link>

            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden flex items-center justify-center h-10 w-10 rounded-lg border border-white/10 bg-[#08101c]"
            >
              {mobileOpen ? <X /> : <Menu />}
            </button>

          </div>

        </div>

      </div>

      {/* MOBILE MENU */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-white/10 bg-[#07101d]/95 backdrop-blur-md">
          <div className="container-main flex flex-col gap-2 py-4">

            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="px-4 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-white/90"
                onClick={() => setMobileOpen(false)}
              >
                {item.label}
              </Link>
            ))}

            <Link
              href="/musteri-girisi"
              className="mt-2 flex justify-center items-center gap-2 rounded-xl bg-orange-500 px-4 py-3 text-white font-semibold"
            >
              <UserCircle2 className="w-4 h-4" />
              Müşteri Girişi
            </Link>

          </div>
        </div>
      )}

      {/* LEFT SIDEBAR (desktop) */}
      <aside
        className={`hidden lg:flex flex-col fixed left-2 w-32 bg-[#0b1624]/90 p-1.5 rounded-xl shadow-lg z-40 transition-transform duration-300 ease-in-out transform ${
          sidebarOpen ? "translate-x-0" : "-translate-x-40"
        }`}
        style={{ overflow: "hidden", top: "calc(120px + 8px)", bottom: "24px" }}
      >
        <div className="mb-1 flex items-center justify-between">
          <div className="text-xs font-semibold text-white">Menü</div>
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="flex h-5 w-5 items-center justify-center rounded-md bg-white/5 text-[10px] text-white"
            aria-label="Toggle sidebar"
          >
            {sidebarOpen ? "‹" : ">"}
          </button>
        </div>

        <nav className="flex flex-col gap-0.5 px-0.5">
          {navItems.map((item) => (
            <div key={item.href}>
              <div className="flex items-center justify-between">
                <Link
                  href={item.href}
                  className="w-full rounded-md bg-white/3 px-1.5 py-1 text-[12px] text-left text-white/95 transition hover:text-white"
                  onClick={() => item.children && setOpenSubmenu(openSubmenu === item.href ? null : item.href)}
                >
                  {item.label}
                </Link>
                {item.children && (
                  <button
                    onClick={() => setOpenSubmenu(openSubmenu === item.href ? null : item.href)}
                    className={`ml-0.5 rounded-md p-0.5 text-white/80 transition-transform duration-200 hover:text-white ${
                      openSubmenu === item.href ? "rotate-180" : "rotate-0"
                    }`}
                    aria-expanded={openSubmenu === item.href}
                  >
                    <ChevronDown className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>

              {item.children && openSubmenu === item.href && (
                <div className="mt-0.5 ml-2 flex flex-col gap-0.5">
                  {item.children.map((ch) => (
                    <Link
                      key={ch.href}
                      href={ch.href}
                      className="rounded-md bg-white/2 px-1.5 py-1 text-[11px] text-white/80 hover:text-white"
                    >
                      {ch.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>

        <div className="mt-1.5 rounded-lg border border-white/10 bg-[#08111d]/95 p-1">
          <div className="mb-1 text-[9px] font-semibold capitalize text-white/85">
            {monthLabel}
          </div>
          <div className="grid grid-cols-7 gap-0.5 text-center text-[8px] text-white/45">
            {weekDays.map((day) => (
              <div key={day} className="py-0">
                {day}
              </div>
            ))}
          </div>
          <div className="mt-0.5 grid grid-cols-7 gap-0.5 text-center text-[8px]">
            {calendarDays.map((day, index) => {
              const isToday = day === today.getDate();

              return (
                <div
                  key={`${day ?? "empty"}-${index}`}
                  className={`flex h-4 items-center justify-center rounded-sm ${
                    day
                      ? isToday
                        ? "bg-orange-500 text-white"
                        : "bg-white/4 text-white/78"
                      : "bg-transparent text-transparent"
                  }`}
                >
                  {day ?? "."}
                </div>
              );
            })}
          </div>
        </div>
      </aside>

      {!sidebarOpen && (
        <button
          type="button"
          onClick={() => setSidebarOpen(true)}
          className="fixed left-2 z-40 hidden h-10 w-10 items-center justify-center rounded-full bg-orange-500 text-white shadow-lg shadow-orange-500/30 transition hover:scale-[1.04] lg:flex"
          style={{ top: "calc(120px + 16px)" }}
          aria-label="Menüyü tekrar göster"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      )}

    </header>
  );
}
