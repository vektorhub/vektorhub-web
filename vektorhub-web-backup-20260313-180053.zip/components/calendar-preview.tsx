const events = [
  { date: "14 Mart", title: "Kurumsal Eğitim Planı" },
  { date: "18 Mart", title: "Teknik Servis Randevusu" },
  { date: "21 Mart", title: "Danışmanlık Oturumu" },
  { date: "27 Mart", title: "Teslim ve Revizyon Günü" },
];

export function CalendarPreview() {
  return (
    <section className="container-main py-16 md:py-24">
      <div className="grid gap-8 xl:grid-cols-[0.92fr_1.08fr]">
        <div>
          <p className="text-sm uppercase tracking-[0.2em] text-orange-300">
            Takvim ve Planlama
          </p>
          <h2 className="section-title mt-3">Göze hoş, işleve yarar.</h2>
          <p className="section-text mt-4">
            Ana sayfadaki takvim alanı sadece görsel blok olmayacak. Eğitimler,
            servis günleri, teslim planları ve görüşmeler burada görünür olacak.
          </p>
        </div>

        <div className="glass-card p-5">
          <div className="grid gap-3">
            {events.map((event) => (
              <div
                key={event.title}
                className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-white/5 p-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <p className="text-sm font-semibold sm:text-base">{event.title}</p>
                  <p className="mt-1 text-xs text-white/50">{event.date}</p>
                </div>

                <div className="rounded-full bg-orange-500/15 px-3 py-1 text-xs font-semibold text-orange-300">
                  Planlı
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}