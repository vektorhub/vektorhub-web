const portalItems = [
  "Paket İnceleme ve Satın Alma",
  "Teklif Takibi",
  "Takvim ve Randevular",
  "Not Defteri",
  "Evrak Merkezi",
  "Duyurular ve Güncellemeler",
  "Süreç ve Görev Takibi",
  "Müşteri Hesap Doğrulama",
];

export function PortalPreview() {
  return (
    <section className="container-main py-16 md:py-24">
      <div className="glass-card p-6 md:p-8">
        <div className="grid gap-8 xl:grid-cols-[1fr_1fr]">
          <div>
            <p className="text-sm uppercase tracking-[0.2em] text-orange-300">
              Müşteri Portalı
            </p>
            <h2 className="section-title mt-3">
              Sadece giriş ekranı değil, dijital çalışma merkezi.
            </h2>
            <p className="section-text mt-4">
              Doğrulanmış müşteriler; hizmet paketlerini, tekliflerini,
              evraklarını, takvimlerini, notlarını ve duyurularını tek panelden
              yönetecek. Amaç müşteriyi rahat ettiren profesyonel çalışma alanı
              kurmak.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {portalItems.map((item) => (
              <div
                key={item}
                className="rounded-2xl border border-white/10 bg-white/5 p-4"
              >
                <p className="text-sm font-semibold leading-6 sm:text-base">
                  {item}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}