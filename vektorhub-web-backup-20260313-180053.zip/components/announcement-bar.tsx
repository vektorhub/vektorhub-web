"use client";

import { useEffect, useState } from "react";

const items = [
  "Yeni danışmanlık paketleri hazırlanıyor",
  "Teknik servis modülü planlanıyor",
  "Müşteri doğrulama altyapısı kurgulanıyor",
  "Portal içi takvim ve not alanı geliyor",
  "Kurumsal faaliyet akışı ana sayfada yayınlanacak",
];

export function AnnouncementBar() {
  const [sidebarVisible, setSidebarVisible] = useState(true);

  useEffect(() => {
    setSidebarVisible(document.body.dataset.leftSidebar !== "collapsed");

    const handleSidebarChange = (event: Event) => {
      const customEvent = event as CustomEvent<{ open: boolean }>;
      setSidebarVisible(customEvent.detail.open);
    };

    window.addEventListener("left-sidebar-change", handleSidebarChange as EventListener);

    return () => {
      window.removeEventListener("left-sidebar-change", handleSidebarChange as EventListener);
    };
  }, []);

  return (
    <>
      {/* Compact right-top announcement box for xl and up -> convert to fixed right sidebar */}
      <aside
        className={`hidden lg:flex flex-col fixed right-2 w-32 bg-[#181c22]/90 p-2 rounded-xl shadow-lg z-50 transition-all duration-300 ${
          sidebarVisible
            ? "translate-x-0 opacity-100 pointer-events-auto"
            : "translate-x-[140%] opacity-0 pointer-events-none"
        }`}
        style={{ top: "calc(120px + 8px)", bottom: "24px" }}
      >
        <div className="mb-1 flex items-center justify-between">
          <div className="inline-flex items-center gap-2">
            <span className="inline-flex w-fit rounded-full bg-orange-500/20 px-1.5 py-0.5 text-[10px] font-semibold text-orange-300">
              Güncellemeler...
            </span>
          </div>

          <div className="flex items-center gap-2" />
        </div>

        {/* Static list (no marquee) */}
        <div className="overflow-auto max-h-[60vh] pr-0.5">
          <ul className="flex flex-col gap-1">
            {items.map((it, i) => (
              <li key={it} className="rounded-md bg-white/2 px-1.5 py-1 text-[12px] text-white/80">
                {it}
              </li>
            ))}
          </ul>
        </div>
      </aside>

      {/* Fallback inline bar for smaller viewports (kept similar to previous) */}
      <div className="lg:hidden glass-card overflow-hidden px-4 py-3">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <span className="inline-flex w-fit rounded-full bg-orange-500/20 px-3 py-1 text-xs font-semibold text-orange-300">
            Duyurular
          </span>

          <div className="overflow-hidden">
            <div className="flex min-w-max animate-[marquee_20s_linear_infinite] gap-10 text-sm text-white/75">
              {items.concat(items).map((item, index) => (
                <span key={`${item}-${index}`}>{item}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}