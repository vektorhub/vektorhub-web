const posts = [
  {
    title: "Saha Teknik Servis Operasyonu",
    tag: "Teknik Servis",
  },
  {
    title: "Üretim Sürecinden Güncel Görünüm",
    tag: "Üretim",
  },
  {
    title: "Kurumsal Danışmanlık Toplantısı",
    tag: "Danışmanlık",
  },
  {
    title: "Eğitim ve Akademi İçeriği",
    tag: "VektörAKADEMİ",
  },
  {
    title: "Tasarım ve Prototip Geliştirme",
    tag: "Endüstriyel Tasarım",
  },
  {
    title: "Müşteri İçin Süreç Planlama",
    tag: "Operasyon",
  },
];

export function InstagramFlow() {
  return (
    <section className="container-main py-16 md:py-24">
      <div className="mb-10 max-w-3xl">
        <p className="text-sm uppercase tracking-[0.2em] text-orange-300">
          Faaliyet Akışı
        </p>
        <h2 className="section-title mt-3">
          Kurumsal vitrinin içinde canlı ve güven veren akış.
        </h2>
        <p className="section-text mt-4">
          Bu alan klasik haber bloğu gibi durmayacak. Firma sahadan, üretimden,
          eğitimden ve süreçlerden gerçek akış veriyormuş hissi verecek.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {posts.map((post, index) => (
          <article key={post.title} className="glass-card overflow-hidden">
            <div className="relative aspect-[4/3] bg-[linear-gradient(135deg,rgba(255,106,0,0.4),rgba(255,255,255,0.04))]">
              <div className="absolute left-4 top-4 rounded-full bg-black/30 px-3 py-1 text-xs font-semibold text-white backdrop-blur">
                #{index + 1}
              </div>
            </div>

            <div className="p-5">
              <span className="rounded-full bg-orange-500/15 px-3 py-1 text-xs font-semibold text-orange-300">
                {post.tag}
              </span>

              <h3 className="mt-4 text-lg font-bold leading-7">{post.title}</h3>

              <p className="mt-3 text-sm leading-7 text-white/65">
                Görsel odaklı paylaşım yapısı sayesinde ziyaretçi faaliyetlerin
                düzenli, aktif ve profesyonel şekilde sürdüğünü görecek.
              </p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}