import Link from "next/link";
import {
  ArrowRight,
  BriefcaseBusiness,
  CalendarDays,
  FileText,
  NotebookPen,
  ShieldCheck,
} from "lucide-react";

const stats = [
  { label: "Hizmet Modülü", value: "12+" },
  { label: "Portal Yapısı", value: "Kurumsal" },
  { label: "Müşteri Deneyimi", value: "Premium" },
];

const features = [
  {
    icon: ShieldCheck,
    title: "Doğrulanmış müşteri girişi",
    desc: "Resmi bilgilerle kayıt, kontrollü erişim ve güvenli portal yapısı.",
  },
  {
    icon: BriefcaseBusiness,
    title: "Paket bazlı hizmet yönetimi",
    desc: "Müşteri tüm hizmetleri ürünleşmiş paket mantığında görecek.",
  },
  {
    icon: CalendarDays,
    title: "Takvim ve operasyon takibi",
    desc: "Randevular, teslim günleri, eğitimler ve planlı işler tek ekranda.",
  },
  {
    icon: NotebookPen,
    title: "Müşteri not alanı",
    desc: "Portal içinde kişisel ve iş bazlı notlarla süreç yönetimi.",
  },
  {
    icon: FileText,
    title: "Evrak ve teklif merkezi",
    desc: "Teklifler, sözleşmeler, faturalar ve dosyalar düzenli panelde.",
  },
];

export function HeroSection() {
  return (
    <section className="container-main pt-8 pb-14 md:pt-12 md:pb-20">
      <div className="grid items-center gap-8 xl:grid-cols-[1.08fr_0.92fr]">
        <div>
          <div className="mb-5 inline-flex rounded-full border border-orange-500/25 bg-orange-500/10 px-4 py-2 text-[11px] font-semibold uppercase tracking-[0.24em] text-orange-300 sm:text-xs">
            VektörHUB Kurumsal Dijital Platform
          </div>

          <h1 className="max-w-5xl text-4xl font-black leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl">
            Kurumsal vitrinden fazlası:
            <span className="brand-gradient block pt-2">
              müşteri portalı ile çalışan yaşayan sistem.
            </span>
          </h1>

          <p className="mt-6 max-w-3xl text-sm leading-7 text-white/72 sm:text-base sm:leading-8 md:text-lg">
            VektörHUB; endüstriyel tasarım, üretim, teknik servis ve danışmanlık
            süreçlerini tek merkezde toplayan güçlü bir dijital yapı olarak
            konumlanacak. Ziyaretçi sadece bilgi almayacak, müşteri ise portal
            içinde tüm işlerini yönetecek.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link
              href="/hizmetler"
              className="inline-flex items-center justify-center rounded-2xl bg-orange-500 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-orange-500/25 transition hover:scale-[1.02]"
            >
              Hizmetleri İncele
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>

            <Link
              href="/musteri-girisi"
              className="inline-flex items-center justify-center rounded-2xl border border-white/15 bg-white/5 px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/10"
            >
              Müşteri Portalına Giriş
            </Link>
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            {stats.map((item) => (
              <div
                key={item.label}
                className="rounded-3xl border border-white/10 bg-white/5 p-4"
              >
                <div className="text-2xl font-black sm:text-3xl">{item.value}</div>
                <div className="mt-2 text-xs uppercase tracking-[0.18em] text-white/45">
                  {item.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-card p-4 sm:p-5 md:p-6">
          <div className="rounded-[28px] border border-white/10 bg-[#0f1728] p-4 sm:p-5 md:p-6">
            <div className="flex flex-col gap-3 border-b border-white/10 pb-5 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-[11px] uppercase tracking-[0.22em] text-white/45 sm:text-xs">
                  Portal Önizleme
                </p>
                <h3 className="mt-2 text-xl font-bold sm:text-2xl">
                  Profesyonel Müşteri Alanı
                </h3>
              </div>

              <div className="inline-flex rounded-full bg-orange-500/15 px-3 py-2 text-xs font-semibold text-orange-300">
                Doğrulanmış Giriş
              </div>
            </div>

            <div className="mt-5 grid gap-3">
              {features.map((item) => {
                const Icon = item.icon;

                return (
                  <div
                    key={item.title}
                    className="flex items-start gap-4 rounded-2xl border border-white/10 bg-white/5 p-4"
                  >
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-orange-500/15 text-orange-300">
                      <Icon className="h-5 w-5" />
                    </div>

                    <div>
                      <h4 className="text-sm font-bold sm:text-base">{item.title}</h4>
                      <p className="mt-1 text-xs leading-6 text-white/62 sm:text-sm">
                        {item.desc}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}