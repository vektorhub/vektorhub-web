const packages = [
  {
    title: "Danışmanlık Paketi",
    desc: "Kurumsal süreç analizi, yol haritası, verimlilik ve operasyonel yönlendirme.",
  },
  {
    title: "Teknik Servis Paketi",
    desc: "Planlı servis, saha desteği, bakım takibi ve teknik çözüm süreçleri.",
  },
  {
    title: "Tasarım / Üretim Paketi",
    desc: "Endüstriyel tasarım, prototip geliştirme, üretim hazırlığı ve teknik dokümantasyon.",
  },
  {
    title: "Eğitim / Akademi Paketi",
    desc: "Kuruma özel eğitim içerikleri, teknik gelişim programları ve bilgi aktarımı.",
  },
];

export function ServicePackages() {
  return (
    <section className="container-main py-16 md:py-24">
      <div className="mb-10 max-w-3xl">
        <p className="text-sm uppercase tracking-[0.2em] text-orange-300">
          Hizmet Paketleri
        </p>
        <h2 className="section-title mt-3">
          Müşteri inceleyecek, kıyaslayacak, teklif alacak.
        </h2>
        <p className="section-text mt-4">
          Her hizmet ürünleşmiş kart yapısında sunulacak. Kapsam, teslim modeli,
          revize hakkı ve satın alma / teklif akışı profesyonel biçimde
          gösterilecek.
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {packages.map((pkg) => (
          <div key={pkg.title} className="glass-card p-6">
            <div className="flex items-start justify-between gap-4">
              <h3 className="text-2xl font-bold">{pkg.title}</h3>
              <span className="rounded-full bg-orange-500/15 px-3 py-1 text-xs font-semibold text-orange-300">
                Paket
              </span>
            </div>

            <p className="mt-4 text-sm leading-7 text-white/68 sm:text-base">
              {pkg.desc}
            </p>

            <div className="mt-6 grid gap-2 text-sm text-white/65">
              <div>• Kapsam net gösterilecek</div>
              <div>• Teslim modeli belirtilecek</div>
              <div>• Teklif veya satın alma yolu açılacak</div>
            </div>

            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <button className="rounded-2xl bg-orange-500 px-5 py-3 text-sm font-semibold text-white">
                İncele
              </button>
              <button className="rounded-2xl border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-white">
                Teklif Al
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}