export default function HizmetlerPage() {
  return (
    <section className="container-main py-20">
      <h1 className="section-title">Hizmetler</h1>
      <p className="section-text mt-6 max-w-3xl">
        Hizmetler bu sayfada paket bazlı, profesyonel ve satın alma / teklif
        akışına uygun şekilde listelenecek.
      </p>
    </section>
  );
}

