export default function AboutPage() {
  return (
    <section className="container-main py-20">
      <h1 className="section-title">Hakkımızda</h1>
      <p className="section-text mt-6 max-w-3xl">
        VektörHUB, endüstriyel tasarım, üretim ve danışmanlık süreçlerini tek
        çatı altında toplayan kurumsal çözüm yapısıdır.
      </p>
    </section>
  );
}

