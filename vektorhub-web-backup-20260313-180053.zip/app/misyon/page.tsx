export default function MisyonPage() {
  return (
    <section className="container-main py-20">
      <h1 className="section-title">Misyon</h1>
      <p className="section-text mt-6 max-w-3xl">
        VektörHUB’un misyonu; müşterilerin endüstriyel tasarım, üretim, teknik
        servis ve danışmanlık süreçlerini sadeleştirmek, hızlandırmak ve
        profesyonel şekilde yönetilebilir hale getirmektir.
      </p>
    </section>
  );
}
