export default function VizyonPage() {
  return (
    <section className="container-main py-20">
      <h1 className="section-title">Vizyon</h1>
      <p className="section-text mt-6 max-w-3xl">
        VektörHUB’un vizyonu; dijital altyapısı güçlü, modern arayüzlü ve
        operasyonel olarak sistemli bir yapı kurarak endüstriyel danışmanlık ve
        üretim alanında öne çıkan bir marka olmaktır.
      </p>
    </section>
  );
}
