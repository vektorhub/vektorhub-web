// AnnouncementBar is rendered globally in the layout
import { CalendarPreview } from "@/components/calendar-preview";
import { HeroSection } from "@/components/hero-section";
import { InstagramFlow } from "@/components/instagram-flow";
import { ServicePackages } from "@/components/service-packages";

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <InstagramFlow />
      <ServicePackages />
      <CalendarPreview />
    </>
  );
}