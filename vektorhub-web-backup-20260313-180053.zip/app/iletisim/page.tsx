export default function IletisimPage() {
  return (
    <section className="container-main py-20">
      <h1 className="section-title">İletişim</h1>
      <div className="mt-6 space-y-3 text-white/75">
        <p>www.vektorhub.com</p>
        <p>info@vektorhub.com</p>
        <p>vektorlabtech@gmail.com</p>
        <p>+90 533 385 05 72</p>
      </div>
    </section>
  );
}

